<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <link href="{{ asset('css/style.css') }}" rel="stylesheet">

    <title>Document</title>
</head>
<body>
<div class="container">

    <div class="row" >
        <div class="col-3" style="background-color: #000;">
            <li class="list-group-item active">Scoreboard</li>
            <ul class="list-group">
                <li class="list-group-item">User 1</li>
                <li class="list-group-item">User 2</li>
                <li class="list-group-item">User 3</li>
                <li class="list-group-item">User 4</li>
                <li class="list-group-item">User 5</li>
            </ul>
        </div>
        <div class="col-6">
            <div class="row">
                <div class="col" style="background-color: #ddd;" id="timer">
                    <timer :time="prettyTime"></timer>
                </div>
                <div class="col" style="background-color: #abc;">
                    <span>The word</span>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <canvas id="canvas" width="550" height="300"></canvas>
                </div>
            </div>
        </div>
        <div class="col-3" id="app">
            <div class="card">
                <h5 class="card-header">Chats</h5>
                <div class="card-body" v-chat-scroll>

                    <chat-messages :messages="messages"></chat-messages>
                </div>
                <div class="card-footer">
                    <chat-form
                        v-on:messagesent="addMessage"
                        :user="{{ Auth::user() }}"
                    ></chat-form>
                </div>
            </div>
            {{--<li class="list-group-item active">Chat Room</li>--}}
            {{--<div class="badge badge-pill badge-primary">@{{ typing }}</div>--}}
            {{--<ul class="list-group" v-chat-scroll>--}}
                {{--<game v-for="value, index in chat.message"--}}
                {{--:key=value.index--}}
                {{--:color= chat.color[index]--}}
                {{--:user = chat.user[index]--}}
                {{--:time = chat.time[index]--}}

                {{-->--}}
                    {{--@{{ value }}--}}
                {{--</game>--}}
            {{--</ul>--}}
            {{--<input class="form-control" type="text" placeholder="type in your answer here..." v-model="message" @keyup.enter="send">--}}
        </div>
    </div>
</div>

<script src="{{ asset('js/app.js') }}"></script>
</body>
</html>